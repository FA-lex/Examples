﻿// Вывести квадрат числа

Console.Write("Input digit: ");
double num = Convert.ToDouble(Console.ReadLine());

double result = num * num;
Console.WriteLine("Square you digit equally = " + result);
